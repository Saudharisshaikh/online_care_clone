package com.braintreepayments.api;

enum DropInExitTransition {
    NO_ANIMATION,
    FADE_OUT
}
