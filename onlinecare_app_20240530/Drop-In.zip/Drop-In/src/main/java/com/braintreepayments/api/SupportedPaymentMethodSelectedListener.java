package com.braintreepayments.api;

interface SupportedPaymentMethodSelectedListener {
    void onPaymentMethodSelected(DropInPaymentMethod type);
}
