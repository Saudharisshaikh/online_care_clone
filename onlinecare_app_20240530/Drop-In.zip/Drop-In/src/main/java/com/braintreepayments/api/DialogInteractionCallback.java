package com.braintreepayments.api;

interface DialogInteractionCallback {
    void onDialogInteraction(DialogInteraction interaction);
}
