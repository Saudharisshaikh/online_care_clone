package com.braintreepayments.api;

interface VaultedPaymentMethodSelectedListener {
    void onVaultedPaymentMethodSelected(PaymentMethodNonce paymentMethodNonce);
}
