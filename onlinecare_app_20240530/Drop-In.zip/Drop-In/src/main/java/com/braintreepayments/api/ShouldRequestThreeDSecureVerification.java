package com.braintreepayments.api;

interface ShouldRequestThreeDSecureVerification {
    void onResult(boolean shouldRequestThreeDSecureVerification);
}
