package com.braintreepayments.api;

enum DropInState {
    IDLE,
    WILL_FINISH
}
