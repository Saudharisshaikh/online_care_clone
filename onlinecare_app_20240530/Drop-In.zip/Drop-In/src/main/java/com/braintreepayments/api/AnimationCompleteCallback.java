package com.braintreepayments.api;

interface AnimationCompleteCallback {
    void onAnimationComplete();
}
