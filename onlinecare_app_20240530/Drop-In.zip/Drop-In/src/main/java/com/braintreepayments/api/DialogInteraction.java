package com.braintreepayments.api;

enum DialogInteraction {
    POSITIVE,
    NEGATIVE
}
