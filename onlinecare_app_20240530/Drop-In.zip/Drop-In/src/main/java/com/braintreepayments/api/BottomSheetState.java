package com.braintreepayments.api;

enum BottomSheetState {
    HIDE_REQUESTED,
    HIDDEN,
    SHOW_REQUESTED,
    SHOWN
}
